$(document).ready(function() {
    var body = $('body'),
        nav = $('.main-menu'),
        panels = $('.panel');
    project = $('.project');


    nav.on('click', 'a', goMenu);
    project.on('click', 'a', goMenu);

    function goMenu(e) {
        e.preventDefault();
        if ($(this).data('panel-link')) {
            var dest = $(this).data('panel-link');
            body
                .removeClass(function(index, css) {
                    return (css.match(/\bshow-\S+/g) || []).join(' ');
                })
                .addClass('show-' + dest);
        }

    }
});