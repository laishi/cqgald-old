
/*COVERFLOW INIT*/
$(document).ready(function() {
  $(".flipster").flipster({
      style: 'carousel',
      team: 0
  });
});

/*WOW INIT*/
$(document).ready(function() {
  var wow = new WOW({
      boxClass: 'wow', // animated element css class (default is wow)
      animateClass: 'animated', // animation css class (default is animated)
      offset: 0, // distance to the element when triggering the animation (default is 0)
      mobile: true, // trigger animations on mobile devices (default is true)
      live: true, // act on asynchronously loaded content (default is true)
      callback: function(box) {
      },
      scrollContainer: null // optional scroll container selector, otherwise use window
  });
  wow.init();
});



/*EXPAND MENU INIT*/
$(document).ready(function() {
  var n = $(".navItem").length; // Div count
  var OW = 38; // Div over width
  TweenMax.set($(".navItem"), {
      width: 100 / n + '%'
  });
  $(".navItem").hover(over, out);

  function over() {
      TweenMax.to($(this), 0.5, {
          width: OW + '%'
      });
      TweenMax.to($(this).siblings(), 0.5, {
          width: (100 - OW) / (n - 1) + '%'
      })
  }

  function out() {
      TweenMax.to($(".navItem"), 0.5, {
          width: 100 / n + '%',
          ease: Back.easeOut
      })
  }
});



/*EXPAND FLOW*/
$(document).ready(function() {
  var filtercont = $(".servicelcs").length;
  var c = $(".servicelc").length / filtercont; // Div count
  var KD = 25; // Div over width
  TweenMax.set($(".servicelc"), {
      width: 100 / c + '%'
  });
  $(".servicelc").hover(over, out);

  function over() {
      TweenMax.to($(this), 0.5, {
          width: KD + '%'
      });
      TweenMax.to($(this).siblings(), 0.5, {
          width: (100 - KD) / (c - 1) + '%'
      })
  }

  function out() {
      TweenMax.to($(".servicelc"), 0.5, {
          width: 100 / c + '%',
          ease: Back.easeOut
      })
  }
});


$(document).ready(function() {
  var filtercont = $(".contacts").length;
  var c = $(".contactItem").length / filtercont; // Div count
  var KD = 40; // Div over width
  TweenMax.set($(".contactItem"), {
      width: 100 / c + '%'
  });
  $(".contactItem").hover(over, out);

  function over() {
      TweenMax.to($(this), 0.5, {
          width: KD + '%'
      });
      TweenMax.to($(this).siblings(), 0.5, {
          width: (100 - KD) / (c - 1) + '%'
      })
  }

  function out() {
      TweenMax.to($(".contactItem"), 0.5, {
          width: 100 / c + '%',
          ease: Back.easeOut
      })
  }
});



/*GOTOTOP INIT*/
$(document).ready(function() {
  $('.isotope-item').on('click', function() {
      $('html,body').animate({
          scrollTop: $(this).offset().top - 50
      }, 1000);
  });
});



/*slipprySlider INIT*/
$(document).ready(function() {
  jQuery('.slippryHeaderSlider').slippry({
      transition: 'fade',
      pager: false,
      auto: true,
      captionsSrc: 'li',
  });

  /*console.log(jQuery('.slippryHeaderSlider').slippry().getSlideCount());*/

  jQuery('.memberSlider').slippry({
      transition: 'fade',
      pager: false,
      // controls
      controls: false,
      autoHover: false,
      speed: 5000,
      // options
      captionsSrc: 'li',
  });

  jQuery('.slipprySlider').slippry({
      transition: 'horizontal',
      pager: false,
      auto: false,
  });
});


/*LOAD ASSETS INIT*/



window.onload = function (){

  var caseSlider = document.querySelector('.isotope');
  var caseItems = document.querySelectorAll('.isotope-item');
  var caseImg = caseSlider.querySelectorAll('img');
  for (var i = 0; i < caseImg.length; i++) {
    var imgSrc = caseImg[i].getAttribute('src').replace('small', 'large');
    caseImg[i].setAttribute("src", imgSrc);
  }

  var lampShow = $('.lampShow');
  lampShow.html("<iframe src='assets/jgd.html' width='100%' height='100%' frameborder='0' scrolling='no'></iframe>");

};

