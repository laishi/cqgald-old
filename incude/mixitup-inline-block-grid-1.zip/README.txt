A Pen created at CodePen.io. You can find this one at http://codepen.io/patrickkunka/pen/tKkAC.

 This pen is part of a tutorial on responsive grids at https://mixitup.kunkalabs.com/learn/tutorial/responsive-grids/