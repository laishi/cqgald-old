A Pen created at CodePen.io. You can find this one at http://codepen.io/laishi/pen/BKNpaE.

 Simple exercise for Material Design Lab

Forked from [Mattia Astorino](http://codepen.io/MattiaAstorino/)'s Pen [Material Papersheet Morphing](http://codepen.io/MattiaAstorino/pen/RNaBwd/).