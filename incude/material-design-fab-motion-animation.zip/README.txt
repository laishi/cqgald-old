A Pen created at CodePen.io. You can find this one at http://codepen.io/laishi/pen/grjBWx.

 Simple experiments about FAB and motion

Forked from [Mattia Astorino](http://codepen.io/MattiaAstorino/)'s Pen [Material Design - FAB Motion Animation](http://codepen.io/MattiaAstorino/pen/eNaNgq/).