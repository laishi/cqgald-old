# Backers

You can join them in supporting  Vue.js development by [pledging on Patreon](https://www.patreon.com/evanyou)! Backers in the same pledge level appear in the order of pledge date.

### $2000

<a href="http://www.thedifferenceengine.io/">
  <img width="600px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/tde.png">
</a>

---

### $500

<a href="http://www.itunescn.com/">
  <img width="240px" src="https://www.zymmm.com/content/images/2016/05/itunescn-logo-4.png">
</a>

<a href="https://jsfiddle.net/">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/jsfiddle.png">
</a>

<a href="https://laravel.com">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/laravel.png">
</a>

<a href="https://chaitin.cn">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/chaitin.png">
</a>

<a href="https://htmlburger.com/">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/htmlburger.png">
</a>

<a href="https://starter.someline.com/">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/someline.png">
</a>

<a href="http://gold.xitu.io/?utm_source=vuejs&utm_medium=image&utm_content=juejin&utm_campaign=q3_website">
  <img width="180px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/juejin.png">
</a>

<a href="http://monterail.com/" target="_blank">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/monterail.png">
</a>

<a href="https://www.trisoft.ro/" target="_blank">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/trisoft.png">
</a>

---

### $250

It could be you!

---

### $100

<a href="http://tighten.co/">
  <img width="200px" src="http://i.imgur.com/T7fQYLT.png">
</a>

<a href="http://invoicemachine.com/">
  <img width="200px" src="http://assets.invoicemachine.com/images/flat_logo.png">
</a>

<a href="https://statamic.com/">
  <img width="240px" src="http://i.imgur.com/MRIkKgp.png">
</a>

<a href="http://nodividestudio.com/">
  <img width="100px" src="https://cloud.githubusercontent.com/assets/499550/16464256/552c2306-3e07-11e6-867f-e4f5ac64bace.png"> No Divide Studio
</a>

---

### $50+

- James Kyle
- Blake Newman
- Lee Smith
- Adam Dorsey
- Greg McCarvell
- Yoshiya Hinosawa
- Wasim Khamlichi
- Jivan Roquet

---

### $10+

- Sylvain Pollet-Villard
- Luca Borghini
- Kazuya Kawaguchi
- Keisuke Kita
- Anirudh Sanjeev
- Guido Bertolino
- Fábio Vedovelli
- Jack Barham
- Stephane Demoote
- Paul R. Dillinger
- Sean Washington
- Alun Davey
- Eduardo Kyvenko
- Thijs de Maa
- Joris Noordermeer
- Niklas Lifors
- An Phan
- Richard Wyke
- Roman Kuba
- Tom Conlon
- Matt Pickle
- Simon East
- Bill Columbia
- Hayden Bickerton
- Henry Zhu
- John Smith
- Benjamin Listwon
- Rainer Morgan
- Brian Jorden
- Christopher Dosin
- Lars Andreas Ness
- Drew Lustro
- Victor Tolbert
- Jon Pokrzyk
- Frank Dungan III
- Lanes.io
- Anders
- Dexter Miguel
- Stephen Michael Hartley
- TJ Fogarty
- Wen-Tien Chang
- Ole Støvern
- Valerian Cure
- Dani Ilops
- louisbl
- Yegor Sytnyk
- Guido H.
- Joan Cejudo
- Ian Walter
- Nikola Trifunovic
- Nicolas Mutis Mesa
- Fahed Toumi
- James
- Spenser
- Takuya Nishio
- Daniel Diekmeier
- Peter Thaleikis
- Karol Fabjanczuk
- Eduardo
- Lê Chương
- Webber Wang
- Daniel Schmitz
- Bruce Li
- Mohammed
- Sam Wainwright
- TJ Hillard
- Kyle Arrington
- Jason Land
- Miljan Aleksic
- James Ye
- Laurids Duellmann
- Christo Crampton
- Adon Metcalfe
- Paul Straw
- Jake Ingman
- Eduardo Camillo
- Barbara Liau
- Jens Lind
- Yegor Sytnyk
- Benson Wong
- Anthony Tsui
- Karol Fabjanczuk
- Isaac Sant
- Milos Stojanovic
- Matsumoto Takamasa
